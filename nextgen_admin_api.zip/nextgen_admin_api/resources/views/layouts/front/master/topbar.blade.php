<div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container-fluid d-flex justify-content-between">
        <div class="d-none d-lg-flex social-links align-items-center">
            <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="#" class="twitter s-icon"><i class="bi bi-twitter"></i></a>
            <a href="#" class="instagram s-icon"><i class="bi bi-instagram"></i></a>
            <a href="#" class="linkedin s-icon"><i class="bi bi-google"></i></i></a>
        </div>

        <div class="contact-info d-flex align-items-center">
            <i class="fas fa-phone-alt me-2"></i><a href="tel:(888) 507-8113">(888) 507-8113</a>
            <i class="fas fa-envelope me-2"></i><a href="mailto:hello@flextms.com">hello@flextms.com</a>
        </div>

    </div>
</div>
