# Admin Panel Template

## If You are going to add some Feature and or you are fixing a bug inside then you need to push inside panel another please Done push code inside a repo


## Steps

1) First Clone the Project

2) After cloning the repo please change the git origin URL Demo

3) After Changing Url then Please Migrate database you can use this command

```
php artisan migrate:fresh --seed
```

4) Also Please Run this command also for  installing all dependency
```
composer install
```

5) Done Admin panel Config Successful

6) Make sure add logo and other info inside site setting

7)Note You can remove readme.md


Theme demo 
Need any change you can check theme
https://themesbrand.com/skote/layouts/index.html

Other Layouts
https://preview.themeforest.net/item/skote-html-laravel-admin-dashboard-template/full_screen_preview/25548061?_ga=2.238064128.1839665091.1628076782-147820294.1628076782


