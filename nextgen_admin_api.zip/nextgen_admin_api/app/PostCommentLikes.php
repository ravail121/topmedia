<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostCommentLikes extends Model
{
    protected $guarded = [];
}
