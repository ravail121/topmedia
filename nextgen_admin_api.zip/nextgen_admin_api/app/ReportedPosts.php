<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReportedPosts extends Model
{
    protected $guarded = [];
}
