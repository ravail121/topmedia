<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CommentReplyLikes extends Model
{
    protected $guarded = [];
}
