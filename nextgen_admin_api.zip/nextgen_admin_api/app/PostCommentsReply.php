<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostCommentsReply extends Model
{
    protected $guarded = [];

    public function user()
    {
        return $this->belongsTo(new User(),"user_id")
            ->select("id","name", "username", "profile_image")->withTrashed();;
    }
}
