<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HidePosts extends Model
{
    protected $guarded = [];
}
